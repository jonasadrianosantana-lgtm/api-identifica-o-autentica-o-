import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-local';
import { AuthService } from '../auth.service';

@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly authService: AuthService) {
    super({ usernameField: 'email', passwordField: 'senha' });
  }

  async validate(usuarios: string, senha: string) {
    const usuario = await this.authService.validarUsuario(email, senha);
    if (!usuarios) {
      throw new Error('Credenciais Invalidas!');
    }
    return usuario;
  }
}
